#
This project comprises HTML, CSS, JavaScript, and Node.js components. All the code is part of the Web Technology course in Computer Engineering at the University of Phayao in Thailand.

# สมาชิกกลุ่ม
- 6602xxxx fname sname
- 6602xxxx fname sname

#install
1. install package
```
npm i
```

2. run website
```
npm run start
```

3. open web browser
```
localhost:3000
```
