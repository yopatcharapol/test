var user = prompt("Your name")
if (user != null){
    document.getElementById('name').textContent = "สวัสดี "+ user
}
