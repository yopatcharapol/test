
element1 = document.getElementById('ele1')

element2 = document.getElementsByClassName('ele2')

element3 = document.getElementsByName('ele3')

element4 = document.getElementsByName('ele4')

element5 = document.querySelectorAll("h1.intro");

