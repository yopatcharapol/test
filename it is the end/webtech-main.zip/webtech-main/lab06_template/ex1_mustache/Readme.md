# Connect Database using Express
- install module 

```
npm install express mustache mustache-express
```

# install mastache extension for vscode

Mustache