i = 1
var j = 2
// let k = 3
const l = 4

// function f4(){
//     const l = 2
//     console.log('l = %d', l)
// }
// f4()
// console.log('l = %d', l)
// f4()

let k = 3
console.log('k = %d', k)
{
    let k = 2
    console.log('k = %d', k)
}
console.log('k = %d', k)


// function f2(){
//     var j = 2
//     console.log('j = %d', j)
// }
// f2()
// console.log('j = %d', j)
// f2()

// function f1(){
//     i = 2
//     console.log('i = %d', i)
// }
// f1()
// console.log('i = %d', i)
// f1()


