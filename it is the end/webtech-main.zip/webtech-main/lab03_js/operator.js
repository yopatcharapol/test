console.log(2/3)
console.log(2%3)
console.log(2**3)