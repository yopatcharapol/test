console.log('H\te\tl\tl\to\neveryone')
console.log('\'Hello\'')
console.log('\"Hello\"')
console.log('C:\\System')

var n = 10, pi = 3.14, gt = 'Hello'
console.log(n, pi, gt)
console.log("n = "+ n + " ,pi = "+ pi + ", gt = "+ gt)
console.log("n = %d, pi = %f, gt = %s", n, pi, gt)
console.log(`n = ${n}, pi = ${pi}, gt = ${gt}`)

console.log(parseInt('9'), parseInt(3.14), parseFloat('3.14'), parseInt('Hello'))