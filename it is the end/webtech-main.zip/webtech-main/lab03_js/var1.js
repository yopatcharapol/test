var logic = "It is true"
var i = 42
var k = 3.14
var l = true
console.log(typeof logic);
console.log(typeof i);
console.log(typeof k);
console.log(typeof l);