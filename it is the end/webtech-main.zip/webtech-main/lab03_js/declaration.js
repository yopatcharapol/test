var x, y, z
let i, j, k

var m = 0, n = 1
let gt = "hello", name = "everyone"

var logic = true // True
var nlogic = false // False

var logic = "It is true"

console.log(typeof logic)